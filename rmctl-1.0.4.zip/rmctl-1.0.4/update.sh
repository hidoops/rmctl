#! /bin/bash

install_path=/opt/rapidminer/contents
command_path=$install_path/rmd

echo "リポジトリフォルダ=$command_path"
if [ -d $command_path ]; then
  # ディレクトリがあるとき
  echo "旧リポジトリフォルダーのライブラリーを更新します。"
  rm -r $command_path/rmctl-lib/lib
fi
if [ ! -d $command_path ]; then
  # rmdディレクトリがないとき
  echo "ツールがインストールされていません。インストールをしてください。"
  exit 1
fi

# confフォルダは残しておく
#mv $install_path/rmd/rmctl-lib/conf $install_path/rmd/rmctl-lib/conf_bkup
cp -r rmd/rmctl-lib/lib $install_path/rmd/rmctl-lib

#echo $command_path

#sudo echo "export HUBCTL_DIR=$command_path" | sudo tee -a /etc/environment
#sudo echo "export PATH=$PATH:$command_path" | sudo tee -a /etc/environment

find $install_path/rmd -type f | xargs chmod +x

# パッケージ確認
pkg=`dpkg -l docker`
if [[ "$pkg" == "" ]]; then
    echo "dockerのインストールが必要です"
else
    echo "dockerはインストール済みです"
fi


if [ -e /usr/local/bin/docker-compose ]; then
    echo "docker-composeはインストール済みです"
else
    echo "docker-composeのインストールが必要です"
fi

pkg=`dpkg -l unzip`
if [[ "$pkg" == "" ]]; then
    echo "unzipのインストールが必要です"
else
    echo "unzipはインストール済みです"
fi

pkg=`dpkg -l wget`
if [[ "$pkg" == "" ]]; then
    echo "wgetのインストールが必要です"
else
    echo "wgetはインストール済みです"
fi
echo ""
echo "アップデート完了！"
