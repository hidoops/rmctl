# rmctl (rmd)

RapidMiner AI Hub を Docker Compose で管理するための CLI ツール。

## セットアップ

```bash
# 1. rmctlのインストール
./install.sh
source /etc/environment

# 2. 依存パッケージのインストール（Docker, zip/unzip, wget, easy-rsa, yq）
rmd tools

# 3. 設定（ライセンス、ホスト名、プロキシ、言語など）
rmd conf

# 4. テンプレート作成＆デプロイ
rmd install <version>          # 例: rmd install 2025.1.1 max y
rmd deploy                     # 例: rmd deploy 2025.1.1-max

# 5. 初回起動
rmd up init

# 6. ステータス確認
rmd status
```

## アップグレード

```bash
rmd install <new_version>          # 例: rmd install 2026.0.0 max y
rmd upgrade                        # 例: rmd upgrade 2026.0.0-max
rmd up init
```

## コマンド一覧

| コマンド | 説明 |
|---------|------|
| `rmd version` | バージョン表示 |
| `rmd install <version> [profile] [y]` | テンプレート作成（profile: min/max/default、2025以降はSSL自動化） |
| `rmd deploy <template>` | デプロイ |
| `rmd upgrade <template>` | アップグレード（PG移行自動対応） |
| `rmd up [init/list/service]` | コンテナ起動（initは初回用、serviceは個別起動） |
| `rmd down [list/service]` | コンテナ停止（serviceは個別停止） |
| `rmd start [service]` | コンテナ開始 |
| `rmd stop [service]` | コンテナ停止 |
| `rmd restart [service]` | コンテナ再起動 |
| `rmd reup [service]` | コンテナ再作成 |
| `rmd status` | ステータス表示 |
| `rmd logs [wso] [keyword]` | ログ表示（w:待機, s:検索, o:ファイル出力、組合せ可） |
| `rmd ssl` | SSL化 |
| `rmd backup [restore]` | バックアップ/リストア |
| `rmd snapshot [restore]` | スナップショット/リストア |
| `rmd rollback` | バックアップからの復元 |
| `rmd pgmigrate [dump/restore]` | PostgreSQL移行（14→17） |
| `rmd clean [i]` | Docker全リソース削除（iはイメージも削除） |
| `rmd tools [rm]` | 依存パッケージ管理（rmはアンインストール） |
| `rmd proxy` | プロキシ設定 |
| `rmd conf` | 設定編集 |
| `rmd update` | conf設定値をデプロイ.envに反映 |
| `rmd undeploy` | アンデプロイ |
| `rmd uninstall [template]` | テンプレート削除 |
| `rmd list [t/b/s/i/p/v]` | 一覧表示（t:テンプレート, b:バックアップ, s:スナップショット, i:イメージ, p:サービス, v:ボリューム） |
| `rmd file [list/e/d/filename]` | デプロイファイル操作（list:一覧, e:.env編集, d:docker-compose.yml編集） |
| `rmd pull` | イメージ取得 |
| `rmd help` | ヘルプ |

## オプション

- `rmd -y <command>` — 非インタラクティブモード（全確認を自動承認）
