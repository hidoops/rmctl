# 使い方
下記のページをご覧ください。

rmctlツール(rmdコマンド)
https://kskds.docbase.io/posts/3077809

拡張版rmctlツール(rmdxコマンド)
https://kskds.docbase.io/posts/3078150

rmctl リリースノート
https://kskds.docbase.io/posts/3297568

