#! /bin/bash

install_path=/opt/rapidminer/contents
command_path=$install_path/rmd

if [ ! -d $command_path ]; then
  # ディレクトリがないとき
  echo "リポジトリフォルダーがないため処理を中断します。"
  exit 1
fi

echo "rmdと環境変数が削除されます。アンインストール続けますか? [Y/n]: "
read ANS

case $ANS in
  "" | [Yy]* )
    # ここに「Yes」の時の処理を書く
    ;;
  * )
    # ここに「No」の時の処理を書く
    echo "処理を中断します。"
    exit 1

    ;;
esac

rm -r $command_path
echo "rmdをアンインストールしました。"

sudo sed -i '/export HUBCTL_DIR/d' /etc/environment
sudo sed -i '/export PATH/d' /etc/environment
echo "環境変数を削除しました。"

# パッケージ確認
pkg=`dpkg -l | grep -i docker`
if [[ "$pkg" == "" ]]; then
    echo "dockerはアンインストール済みです"
else
    echo "dockerはアンインストールされていません。必要に応じて削除してください。"
fi

if [ -e /usr/local/bin/docker-compose ]; then
    echo "docker-composeはアンインストールされていません。必要に応じて削除してください。"
else
    echo "docker-composeはアンインストール済みです"
fi

pkg=`dpkg -l | grep -i unzip`
if [[ "$pkg" == "" ]]; then
    echo "unzipはアンインストール済みです"
else
    echo "unzipはアンインストールされていません。必要に応じて削除してください。"
fi

pkg=`dpkg -l | grep -i wget`
if [[ "$pkg" == "" ]]; then
    echo "wgetはアンインストール済みです"
else
    echo "wgetはアンインストールされていません。必要に応じて削除してください。"
fi
