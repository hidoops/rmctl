#!/bin/bash
# 共通関数

# インタラクティブ確認（RMD_YES=true の場合はデフォルト値を使用）
# 使用例: ask_yn "実行しますか？" "Y" ANS
#   第1引数: プロンプトメッセージ
#   第2引数: デフォルト値 (Y or N)
#   第3引数: 結果を格納する変数名
ask_yn() {
    local prompt=$1
    local default=$2
    local varname=$3

    if [[ "$RMD_YES" == "true" ]]; then
        eval "$varname=$default"
        echo "${prompt} [auto: ${default}]"
    else
        if [[ "$default" == "Y" ]]; then
            echo -n "${prompt} [Y/n]: "
        else
            echo -n "${prompt} [y/N]: "
        fi
        read $varname
        # 空入力の場合はデフォルト値を使用
        if [[ -z "${!varname}" ]]; then
            eval "$varname=$default"
        fi
    fi
}
